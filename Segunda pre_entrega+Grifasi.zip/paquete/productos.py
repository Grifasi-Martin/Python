import json

class productos:
    def __init__(self):
        self.lista_productos = []
        self.carrito = []

    def cargar_productos(self):
        try:
            with open("productos.json", "r") as archivo:
                self.lista_productos = json.load(archivo)
        except FileNotFoundError:
            pass

    def agregar_productos(self, id, nombre, precio, descripcion):
        producto = {"id": id, "nombre": nombre, "precio": precio, "descripcion": descripcion}
        self.lista_productos.append(producto)
        with open("productos.json", "a") as archivo:
            json.dump(self.lista_productos, archivo)
        archivo.close()
        print("Producto agregado correctamente!.")
    
    def stock_productos():
        with open("productos.json", "r") as archivo:
            productos = json.load(archivo)
    
        print("Stock MarketCons:")
        for id, nombre in productos.items():
            print(f"ID: {id}, Producto: {nombre}")
        archivo.close()

    def compra_productos(self, nombre):
        for producto in self.lista_productos:
            if producto["nombre"] == nombre:
                self.carrito.append(producto)
                print(f"Se agregó '{nombre}' al carrito.")
                return
        print(f"No se encontró el producto en la lista.")

    def mostrar_carrito(self):
        if len(self.carrito) > 0:
            print("Productos en el carrito:")
            for producto in self.carrito:
                print(f"Nombre producto: {producto['nombre']}, Precio: {producto['precio']}")
        else:
            print("El carrito está vacío.")
