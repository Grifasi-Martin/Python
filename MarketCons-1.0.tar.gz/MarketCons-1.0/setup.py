from setuptools import setup

setup(
    name= "MarketCons",
    version= "1.0",
    description= "Programa tipo market",
    author= "Martin Grifasi",
    author_email= "magrifasi@gmail.com",
    packages= ["paquete"]
)