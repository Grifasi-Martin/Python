import json

class clientes:
    def __init__(self, usuario, nombre, contra, mail, cuit):
        self.usuario = usuario
        self.nombre = nombre
        self.contra = contra
        self.mail = mail
        self.cuit = cuit

    def __str__(self):
        return f"Usuario registrado: {self.nombre} - Email: {self.usuario} - CUIT: {self.cuit}"
    
    def leer_datos():
        with open("usuarios.json", "r") as archivo:
            usuarios = json.load(archivo)
    
        print("Base de datos MarketCons:")
        for usuario, contra in usuarios.items():
            print(f"Usuario: {usuario}, Contraseña: {contra}")
        archivo.close()
    
    def guardar_datos(usuarios):
        with open("usuarios.json", "w") as archivo:
            json.dump(usuarios, archivo)

    def registro_usuario(self):
        self.usuario
        self.nombre
        self.contra
        self.mail
        self.cuit
        
        usuarios = clientes.leer_datos()
        
        if self.usuario in usuarios:
            print("Usuario ya registrado.")
        else:
            usuarios[self.usuario] = self.contra
            clientes.guardar_datos(usuarios)
            print(f"Usuario registrado correctamente!")

    def ingreso_usuario(self):
        self.usuario
        self.contra
        self.nombre
        
        usuarios = clientes.leer_datos()

        if self.usuario in usuarios and usuarios[self.usuario] == self.contra:
            print(f"Inicio de sesión exitoso.\nBienvenido a MarketCons {self.usuario}!.")
        else:
            print("El usuario no fue encontrado por favor registrese.")



